from django.http import HttpResponse

def index(request):
    return HttpResponse('<a class="nav-link" href="/user/">Working</a>')